﻿using System.Web.Mvc;

namespace MVCFirst.Controllers
{
    public class ImageResult : ActionResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            context.RequestContext.HttpContext.Response.Write("<img src='" + UrlHelper.GenerateContentUrl("~/p.jpg", context.HttpContext)+"' />");
        }
    }

    public class ImageController : Controller
    {
        // GET: Image
        public ActionResult Index()
        {
            return new ImageResult();
        }
    }
}