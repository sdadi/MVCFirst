﻿using MVCFirst.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCFirst.Controllers
{
    public class EmployeeModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            Employee emp = new Employee();
            emp.Name = controllerContext.HttpContext.Request.Form["Address"];
            emp.Address = controllerContext.HttpContext.Request.Form["Name"];
            return emp;
        }
    }

    public class EmployeeController : Controller
    {
        private readonly string Message;
        public EmployeeController(string message)
        {
            Message = message;
        }
        protected override bool DisableAsyncSupport
        {
            get
            {
                return true;
            }
        }
        protected override void ExecuteCore()
        {
            if (null != Session["language"])
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(Session["language"].ToString());
            }
            base.ExecuteCore();
        }
        // GET: Employee
        public ActionResult Index()
        {
            Employee emp = new Employee { Name = "Satish", Address = "Nellore" };
            return View(emp);
        }
        public ActionResult Save(Employee employee)
        {
            return View("Index");
        }
        public ActionResult EmpView()
        {
            List<Employee> employees = new List<Employee>
            {
                new Employee{Name="Satish",Address="Bangalore"},
                new Employee{Name="Harish",Address="Hyderabad"}
            };
            return View(employees);
        }
        public ActionResult ChangeLanguage(string id)
        {
            Session["language"] = id;
            return RedirectToAction("EmpView","employee");
        }
    }
}