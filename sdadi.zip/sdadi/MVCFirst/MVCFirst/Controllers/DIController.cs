﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCFirst.Controllers
{
    public interface IManager
    {
        string GetData();
    }
    public class Manager : IManager
    {
        public string GetData()
        {
            return "Manager: Satish DADI";
        }
    }
    public class ManagerStub : IManager
    {
        public string GetData()
        {
            return "ManagerStub:SatishDADI";
        }
    }


    public class DIController : Controller
    {
        private readonly IManager _manager;
        public DIController(IManager manager)
        {
            _manager = manager;
        }
        // GET: DI
        public ActionResult Index()
        {
            return Content(_manager.GetData());
        }
    }
}