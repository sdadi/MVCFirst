﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace WebApiFirst.Handlers
{
    public class HttpMethodOverrideMessageHandler:DelegatingHandler
    {
        protected override System.Threading.Tasks.Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
        {
            if (request.Method == HttpMethod.Post && request.Headers.Contains("x-http-method-override"))
            {
                var method = request.Headers.GetValues("x-http-method-override").FirstOrDefault();
                request.Method = new HttpMethod(method);
            }
            return base.SendAsync(request, cancellationToken);
        }
    }
}