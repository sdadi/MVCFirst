﻿using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;

namespace WebApiFirst.Controllers
{
    public class Credential
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
    public class CookieController : ApiController
    {
        public string Get()
        {
            var cookie = Request.Headers.GetCookies("UId").First();
            return cookie["UId"].Value;
        }
        public HttpResponseMessage Post(Credential credential)
        {
            var response = new HttpResponseMessage();
            var cookies = new CookieHeaderValue("UId", "U396343" + credential.Login);
            response.Headers.AddCookies(new CookieHeaderValue[] { cookies });

            return response;
        }
    }
}
