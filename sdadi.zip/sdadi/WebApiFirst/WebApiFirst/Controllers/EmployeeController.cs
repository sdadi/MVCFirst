﻿using System.Web.Http;

namespace WebApiFirst.Controllers
{
    public class Employee
    {
        public string Name { get; set; }
        public string Address { get; set; }
    }
    public class EmployeeController : ApiController
    {
        [HttpGet]
        public Employee Sample()
        {
            var emp = new Employee { Name = "Subrahmanyam", Address = "Nellore" };
            return emp;
        }
        public Employee Get()
        {
            var emp = new Employee { Name = "Satish", Address = "Bengaluru" };
            return emp;
        }

        public Employee Post(Employee e)
        {
            var emp = new Employee { Name = "Harish", Address = "Hyderabad" };
            return emp;
        }
    }
}
