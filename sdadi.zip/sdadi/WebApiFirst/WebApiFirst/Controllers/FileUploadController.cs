﻿
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace WebApiFirst.Controllers
{
    public class FileUploadController : ApiController
    {
        public async Task<string> Post()
        {
            var uploadPath = HttpContext.Current.Server.MapPath("~/UploadFiles");
            var streamProvider = new MultipartFormDataStreamProvider(uploadPath);

            await Request.Content.ReadAsMultipartAsync(streamProvider);
            string content = File.ReadAllText(streamProvider.FileData.FirstOrDefault().LocalFileName);
            return content;
        }
    }
}
