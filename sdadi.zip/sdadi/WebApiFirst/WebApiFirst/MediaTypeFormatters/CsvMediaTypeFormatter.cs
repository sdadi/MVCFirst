﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using WebApiFirst.Controllers;

namespace WebApiFirst.MediaTypeFormatters
{
    public class CsvMediaTypeFormatter:BufferedMediaTypeFormatter
    {
        public CsvMediaTypeFormatter()
        {
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/csv"));
        }
        public override bool CanReadType(Type type)
        {
            return false;
        }

        public override bool CanWriteType(Type type)
        {
            return true;
        }
        public override void WriteToStream(Type type, object value, Stream writeStream, HttpContent content)
        {
            using (var writer = new StreamWriter(writeStream))
            {
                var emp = value as Employee;
                writer.WriteLine(string.Format(@"{0},{1}",emp.Name,emp.Address));
            }
        }
    }
}