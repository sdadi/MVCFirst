﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace MVCFirst.CustomViewEngines
{
    public class CustomViewEngine:VirtualPathProviderViewEngine
    {
        public CustomViewEngine()
        {
            this.ViewLocationFormats = new string[] { "~/customviews/{1}/{0}.dshtml" };
            this.PartialViewLocationFormats = new string[] { "~/customviews/{1}/{0}.dshtml" };
        }
        protected override IView CreatePartialView(ControllerContext controllerContext, string partialPath)
        {
            return new CustomView(partialPath);
        }

        protected override IView CreateView(ControllerContext controllerContext, string viewPath, string masterPath)
        {
            return new CustomView(viewPath,masterPath);
        }
    }

    public class CustomView : IView
    {
        private string _viewPath;
        private string _masterPath;
        private string _partialPath;

        public CustomView(string viewPath, string masterPath)
        {
            // TODO: Complete member initialization
            this._viewPath = viewPath;
            this._masterPath = masterPath;
        }

        public CustomView(string partialPath)
        {
            // TODO: Complete member initialization
            this._partialPath = partialPath;
        }
        public void Render(ViewContext viewContext, System.IO.TextWriter writer)
        {
            string content = File.ReadAllText(viewContext.HttpContext.Server.MapPath(_viewPath));

            if (viewContext.ViewData != null)
            {
                foreach (KeyValuePair<string,object> item in viewContext.ViewData)
                {
                    content = content.Replace(string.Format(@"#ViewData.{0}", item.Key), item.Value.ToString());
                }
            }

            writer.WriteLine(content);
        }
    }
}