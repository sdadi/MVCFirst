﻿using MVCFirst.CustomViewEngines;
using System;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.SessionState;

namespace MVCFirst
{
    public class HelloWorldControllerFactory : IControllerFactory
    {
        public IController CreateController(RequestContext requestContext, string controllerName)
        {
            Type type = Type.GetType("MVCFirst.Controllers." + controllerName + "Controller");
            IController controller = Activator.CreateInstance(type, "Satish Hello World") as IController;
            return controller;
        }

        public SessionStateBehavior GetControllerSessionBehavior(RequestContext requestContext, string controllerName)
        {
            return SessionStateBehavior.Default;
        }

        public void ReleaseController(IController controller)
        {
            (controller as IDisposable).Dispose();
        }
    }

    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            ViewEngines.Engines.Add(new CustomViewEngine());
            //ControllerBuilder.Current.SetControllerFactory(new HelloWorldControllerFactory());
            // Code that runs on application startup
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            UnityConfig.RegisterComponents();
        }
    }
}