﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCFirst.Models
{
    public class Employee
    {
        [Display(Name="Name",ResourceType=typeof(Resources.Employee))]
        public string Name { get; set; }
        [Display(Name = "Address", ResourceType = typeof(Resources.Employee))]
        public string Address { get; set; }
    }
}