﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace MVCFirst.Controllers
{
    
    public class FileUploadController : Controller
    {
        // GET: FileUpload
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Upload(string Name, HttpPostedFileBase[] PostFile)
        {
            StreamReader reader = new StreamReader(PostFile[1].InputStream);
            return Content(reader.ReadToEnd());
        }
        public ActionResult AjaxUpload(string Name, HttpPostedFileBase[] PostFile)
        {
            StringBuilder content = new StringBuilder();
            foreach (var file in PostFile)
            {
                StreamReader reader = new StreamReader(file.InputStream);
                content.AppendLine(reader.ReadToEnd());
            }
            return Content(content.ToString());
        }
    }
}