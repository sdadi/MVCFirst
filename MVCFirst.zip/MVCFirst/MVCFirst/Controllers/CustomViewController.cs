﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCFirst.Controllers
{
    public class CustomViewController : Controller
    {
        // GET: Image
        public ActionResult Index()
        {
            ViewData["Training"]="MVC Advanced";
            ViewData["Trainer"] = "Sukesh Marla";
            return View();
        }
    }
}